using System.Collections.Generic;
using UnityEngine;

namespace Aurum {
// All typography uses an included bitmap atlas, also on headsets without Chinese system fonts.
public class Paper {
    readonly Transform book;
    readonly List<GameObject> lines=new List<GameObject>();
    static Material glyphs;
    static string alphabet;
    static readonly Dictionary<string,Material> images=new Dictionary<string,Material>();
    public Paper(Transform root) {book=root;}
    public void Clear() {foreach(var g in lines) Object.Destroy(g);lines.Clear();}
    void Quad(string label,List<Vector3> v,List<Vector2> uv,List<int> t,Material mat) {
        var g=new GameObject(label);g.transform.SetParent(book,false);var mesh=new Mesh();
        mesh.SetVertices(v);mesh.SetUVs(0,uv);mesh.SetTriangles(t,0);mesh.RecalculateBounds();
        g.AddComponent<MeshFilter>().sharedMesh=mesh;g.AddComponent<MeshRenderer>().sharedMaterial=mat;
        g.AddComponent<PaperMesh>().owned=mesh;lines.Add(g);
    }
    public void Text(string str,float x,float z,float size) {
        if(glyphs==null) {
            alphabet=Resources.Load<TextAsset>("Aurum/Alphabet").text.TrimStart('\uFEFF').TrimEnd();
            glyphs=Models.Paint("Letterpress",Color.white,true);glyphs.mainTexture=Resources.Load<Texture2D>("Aurum/Type");
        }
        var vs=new List<Vector3>();var uv=new List<Vector2>();var tri=new List<int>();
        int rows=glyphs.mainTexture.height/48;int cols=glyphs.mainTexture.width/48;
        foreach(char c in str) {
            if(c==' '){x+=size*.48f;continue;}
            int k=alphabet.IndexOf(c);if(k<0)k=alphabet.IndexOf('?');
            float u=(k%cols)/(float)cols,v=1-(k/cols+1)/(float)rows;
            Add(vs,uv,tri,x,z,size,size,u,v,1f/cols,1f/rows);x+=size*(c<128?.65f:1f);
        }
        if(vs.Count>0)Quad(str,vs,uv,tri,glyphs);
    }
    static void Add(List<Vector3> p,List<Vector2> uv,List<int> t,float x,float z,float w,float h,float u,float v,float du,float dv) {
        int a=p.Count;float y=.0142f;
        p.AddRange(new[]{new Vector3(x,y,z),new Vector3(x,y,z-h),new Vector3(x+w,y,z-h),new Vector3(x+w,y,z)});
        uv.AddRange(new[]{new Vector2(u,v+dv),new Vector2(u,v),new Vector2(u+du,v),new Vector2(u+du,v+dv)});
        t.AddRange(new[]{a,a+2,a+1,a,a+3,a+2});
    }
    public void Icon(string id) {
        if(!images.TryGetValue(id,out var mat)){mat=Models.Paint(id,Color.white,true);mat.mainTexture=Resources.Load<Texture2D>("Aurum/"+id);images.Add(id,mat);}
        var p=new List<Vector3>();var uv=new List<Vector2>();var t=new List<int>();
        Add(p,uv,t,-.119f,.050f,.094f,.094f,0,0,1,1);Quad(id,p,uv,t,mat);
    }
}
public class PaperMesh:MonoBehaviour {public Mesh owned;void OnDestroy(){if(owned)Destroy(owned);}}
}
