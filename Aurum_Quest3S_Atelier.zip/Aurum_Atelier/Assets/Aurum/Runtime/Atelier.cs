using UnityEngine;
using UnityEngine.XR;
using System.Collections.Generic;
using System.Linq;

namespace Aurum {
public class Atelier:MonoBehaviour {
    public static Atelier Active {get;private set;}
    public Transform TrackingSpace {get;private set;}
    public static System.Func<int,Pose?> Finger;
    public static System.Func<int,float> Gap;
    Camera eye; GameObject avatar,visitor,jewel,torch,loupe,ledger,report,detail;
    Light beam; Paper prices,record;
    Item[] list; Item item;
    readonly Queue<int> bag=new Queue<int>();
    readonly GameObject[] held=new GameObject[2],tips=new GameObject[2];
    readonly bool[] squeezed=new bool[2];
    readonly Vector3[] offsets=new Vector3[2];
    readonly Quaternion[] twists=new Quaternion[2];
    readonly Dictionary<GameObject,Pose> docks=new Dictionary<GameObject,Pose>();
    readonly Vector3 tray=new Vector3(0,.857f,.06f),door=new Vector3(1.86f,0,3.3f),counter=new Vector3(0,0,.82f);
    int page,caseNo,flaw; bool fake,lit,seen,submitted,verdict,calibrated,leaving,arrived;
    float timer; GameObject mount; GameObject[] sourceMarks,zoomMarks;
    readonly string[] flaws={"潔淨","氣泡群","分岔裂紋","深色內含物"};
    readonly float[] factors={1,.83f,.62f,.88f};
    int Amount=>Mathf.RoundToInt(item.price*(fake?.12f:1)*factors[flaw]);
    GameObject Obj(string key,Vector3 p)=>Models.Make(key,p,transform);
    void Start(){
        Active=this;list=Models.Data<Catalogue>("Catalogue").items;
        Obj("Salon",Vector3.zero);
        avatar=Obj("SeatedBody",new Vector3(0,0,-.65f));avatar.transform.rotation=Quaternion.Euler(0,180,0);
        
        torch=Dock("Torch",new Vector3(.30f,.849f,-.23f),-18);
        loupe=Dock("Loupe",new Vector3(.45f,.837f,-.22f),15);
        ledger=Dock("Ledger",new Vector3(-.39f,.824f,-.19f),0);
        report=Dock("Report",new Vector3(-.37f,.824f,.07f),0);
        prices=new Paper(ledger.transform);record=new Paper(report.transform);
        var l=new GameObject("Inspection beam");l.transform.SetParent(torch.transform,false);l.transform.localPosition=Vector3.forward*.081f;
        beam=l.AddComponent<Light>();beam.type=LightType.Spot;beam.spotAngle=34;beam.range=.72f;beam.intensity=3.4f;beam.color=new Color(1,.91f,.73f);
        var fill=new GameObject("Daylight").AddComponent<Light>();fill.type=LightType.Directional;fill.transform.rotation=Quaternion.Euler(48,-35,0);fill.intensity=1.25f;
        RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;RenderSettings.ambientLight=new Color(.65f,.65f,.64f);
        TrackingSpace=new GameObject("Seated tracking origin").transform;TrackingSpace.SetParent(transform,false);
        eye=Camera.main;if(!eye){eye=new GameObject("Player eye").AddComponent<Camera>();eye.tag="MainCamera";}
        eye.transform.SetParent(TrackingSpace,false);eye.nearClipPlane=.015f;eye.farClipPlane=20;
        eye.transform.localPosition=new Vector3(0,1.27f,-.63f);eye.transform.localRotation=Quaternion.Euler(24,0,0);
        for(int i=0;i<2;i++){
            tips[i]=GameObject.CreatePrimitive(PrimitiveType.Sphere);tips[i].name="Pinch cursor";Destroy(tips[i].GetComponent<Collider>());tips[i].transform.localScale=Vector3.one*.014f;tips[i].SetActive(false);
        }
        DrawPrices();Begin();
    }
    GameObject Dock(string key,Vector3 p,float yaw){var g=Obj(key,p);g.transform.rotation=Quaternion.Euler(0,yaw,0);docks[g]=new Pose(p,g.transform.rotation);return g;}
    void Begin(){
        if(visitor)Destroy(visitor);if(jewel){for(int h=0;h<2;h++)if(held[h]==jewel)held[h]=null;docks.Remove(jewel);Destroy(jewel);}
        if(detail)Destroy(detail);
        if(bag.Count==0){var pool=Enumerable.Range(0,list.Length).ToList();while(pool.Count>0){int n=Random.Range(0,pool.Count);bag.Enqueue(pool[n]);pool.RemoveAt(n);}}
        caseNo++;item=list[bag.Dequeue()];fake=Random.value<.35f;flaw=Random.value<.22f?0:Random.Range(1,4);
        lit=seen=submitted=arrived=leaving=false;timer=0;
        visitor=Obj("Visitor"+((caseNo-1)%3+1),door);
        jewel=Obj(item.id,tray);docks[jewel]=new Pose(tray,Quaternion.identity);
        // Select a real, upward-facing exterior triangle. A downward ray excludes occluded faces and empty ring centres.
        var mesh=jewel.GetComponent<MeshFilter>().sharedMesh;var bounds=mesh.bounds;var collider=jewel.AddComponent<MeshCollider>();
        collider.sharedMesh=mesh;Physics.SyncTransforms();
        Vector3 spot=Vector3.zero,normal=Vector3.up;bool hitSurface=false;
        for(int k=0;k<180&&!hitSurface;k++){
            var v=new Vector3(Random.Range(bounds.min.x,bounds.max.x),bounds.max.y+.04f,Random.Range(bounds.min.z,bounds.max.z));
            if(collider.Raycast(new Ray(tray+v,Vector3.down),out var hit,.3f)){
                normal=hit.normal;spot=hit.point-tray;hitSurface=true;
            }
        }
        if(!hitSurface){var verts=mesh.vertices;spot=verts.OrderByDescending(v=>v.y).First();}
        mount=new GameObject("Inspection site");mount.transform.SetParent(jewel.transform,false);mount.transform.localPosition=spot+normal*.00035f;mount.transform.localRotation=Quaternion.FromToRotation(Vector3.up,normal);
        if(flaw!=0)Models.Make(new[]{"","Bubble","Crack","Inclusion"}[flaw],Vector3.zero,mount.transform);
        // A game-only fluorescent maker mark: one bead for genuine, a doublet for replicas.
        sourceMarks=new GameObject[fake?2:1];
        for(int j=0;j<sourceMarks.Length;j++){
            var dot=GameObject.CreatePrimitive(PrimitiveType.Sphere);Destroy(dot.GetComponent<Collider>());dot.transform.SetParent(mount.transform,false);
            dot.transform.localPosition=new Vector3(-.0014f+j*.0028f,.00045f,-.0019f);dot.transform.localScale=new Vector3(.0019f,.00065f,.0019f);
            dot.GetComponent<Renderer>().sharedMaterial=MarkMaterial;dot.name="Maker mark";dot.SetActive(false);sourceMarks[j]=dot;
        }
        jewel.transform.SetParent(visitor.transform,false);jewel.transform.localPosition=new Vector3(.213f,.875f,-.097f);
        DrawReport();
    }
    Material markMat;
    Material MarkMaterial { get {if(!markMat)markMat=Models.Paint("Fluorescent mint",new Color(.35f,1,.66f));return markMat;} }
    void Update(){
        if(!visitor)return;
        timer+=Time.deltaTime;
        if(!arrived||leaving){
            float t=Mathf.Clamp01(timer/2.4f),u=Mathf.SmoothStep(0,1,t);
            Vector3 a=leaving?counter:door,b=leaving?door:counter;
            visitor.transform.position=Vector3.Lerp(a,b,u)+Vector3.up*(.013f*Mathf.Sin(t*Mathf.PI*10)*Mathf.Sin(t*Mathf.PI));
            var dir=b-a;visitor.transform.rotation=Quaternion.Slerp(Quaternion.LookRotation(-dir),Quaternion.identity,leaving?0:Mathf.SmoothStep(0,1,(t-.7f)/.3f));
            if(t>=1){if(leaving){Begin();return;}arrived=true;jewel.transform.SetParent(transform,true);Restore(jewel);DrawReport();}
        }
        Track();Inspect();
    }
    void Track() {
        var head=InputDevices.GetDeviceAtXRNode(XRNode.Head);
        if(head.TryGetFeatureValue(CommonUsages.devicePosition,out Vector3 hp)&&head.TryGetFeatureValue(CommonUsages.deviceRotation,out Quaternion hr)){
            if(!calibrated){
                TrackingSpace.rotation=Quaternion.Euler(0,-hr.eulerAngles.y,0);
                TrackingSpace.position=new Vector3(0,1.25f,-.60f)-TrackingSpace.rotation*hp;calibrated=true;
            }
            eye.transform.SetLocalPositionAndRotation(hp,hr);
        }
        for(int i=0;i<2;i++){
            Pose? pose=Finger?.Invoke(i);bool down=false;
            if(pose.HasValue)down=Gap(i)<(squeezed[i]?.038f:.023f);
            else {
                var dev=InputDevices.GetDeviceAtXRNode(i==0?XRNode.LeftHand:XRNode.RightHand);
                if(dev.TryGetFeatureValue(CommonUsages.devicePosition,out var p)&&dev.TryGetFeatureValue(CommonUsages.deviceRotation,out var q)){
                    pose=new Pose(p,q);dev.TryGetFeatureValue(CommonUsages.gripButton,out down);
                }
            }
            tips[i].SetActive(pose.HasValue);
            if(!pose.HasValue){Release(i);squeezed[i]=false;continue;}
            Vector3 pt=TrackingSpace.TransformPoint(pose.Value.position);Quaternion rot=TrackingSpace.rotation*pose.Value.rotation;tips[i].transform.position=pt;
            if(down&&!squeezed[i]){
                if(!BookButton(pt)) {
                    GameObject best=null;float dist=.085f;
                    foreach(var g in docks.Keys){
                        if(g==held[1-i]||(g==jewel&&(!arrived||leaving)))continue;
                        float d=Vector3.Distance(pt,g.GetComponent<Renderer>().bounds.ClosestPoint(pt));if(d<dist){best=g;dist=d;}
                    }
                    if(best){held[i]=best;offsets[i]=Quaternion.Inverse(rot)*(best.transform.position-pt);twists[i]=Quaternion.Inverse(rot)*best.transform.rotation;}
                }
            }
            if(!down&&squeezed[i])Release(i);
            if(held[i])held[i].transform.SetPositionAndRotation(pt+rot*offsets[i],rot*twists[i]);squeezed[i]=down;
        }
    }
    void Release(int h){if(held[h])Restore(held[h]);held[h]=null;}
    void Restore(GameObject g){var p=docks[g];g.transform.SetPositionAndRotation(p.position,p.rotation);}
    bool BookButton(Vector3 pt){
        foreach(var book in new[]{ledger,report}){
            Vector3 p=book.transform.InverseTransformPoint(pt);
            if(Mathf.Abs(p.y-.017f)>.034f||p.z<-.103f||p.z>-.054f||Mathf.Abs(p.x)>.151f)continue;
            if(book==ledger)Flip(p.x<0?-1:1);
            else if(submitted)Next();else Submit(p.x>=0);return true;
        }return false;
    }
    void Inspect(){
        if(!arrived||leaving)return;
        Vector3 sample=mount.transform.position;Vector3 delta=sample-beam.transform.position;
        bool lightOn=delta.magnitude<beam.range&&Vector3.Angle(beam.transform.forward,delta)<beam.spotAngle*.5f;
        foreach(var c in sourceMarks)if(c.activeSelf!=lightOn)c.SetActive(lightOn);
        Vector3 center=loupe.transform.TransformPoint(new Vector3(0,0,.023f));Vector3 toEye=eye.transform.position-center;
        Vector3 ray=sample-center;
        bool close=ray.magnitude<.115f&&Vector3.Dot(ray,toEye)<0&&Vector3.Angle(ray,-toEye)<34&&Mathf.Abs(Vector3.Dot(loupe.transform.up,toEye.normalized))>.45f;
        if(close&&!detail){
            detail=Instantiate(jewel);zoomMarks=detail.GetComponentsInChildren<Transform>(true).Where(t=>t.name=="Maker mark").Select(t=>t.gameObject).ToArray();detail.name="Optical enlargement";detail.transform.SetParent(transform,false);
            foreach(var c in detail.GetComponentsInChildren<Collider>())Destroy(c);
        }
        if(detail){detail.SetActive(close);if(close){
            float zoom=Mathf.Min(2.2f,.072f/jewel.GetComponent<MeshFilter>().sharedMesh.bounds.size.magnitude);
            zoom=Mathf.Max(1.12f,zoom);detail.transform.localScale=Vector3.one*zoom;detail.transform.rotation=jewel.transform.rotation;
            detail.transform.position=center+toEye.normalized*.006f-(sample-jewel.transform.position)*zoom;
            foreach(var r in zoomMarks)if(r.activeSelf!=lightOn)r.SetActive(lightOn);
        }}
        bool changed=(!lit&&lightOn)||(!seen&&close);
        lit|=lightOn;seen|=close;if(changed)DrawReport();
    }
    void Flip(int d){page=(page+d+list.Length)%list.Length;DrawPrices();}
    void Submit(bool replica){if(!arrived||submitted||!lit||!seen||leaving)return;submitted=true;verdict=replica;DrawReport();}
    void Next(){if(!submitted||leaving)return;
        for(int h=0;h<2;h++)if(held[h]==jewel)Release(h);
        if(detail)detail.SetActive(false);jewel.transform.SetParent(visitor.transform,false);jewel.transform.localPosition=new Vector3(.213f,.875f,-.097f);
        leaving=true;timer=0;
    }
    void DrawPrices(){
        var row=list[page];prices.Clear();prices.Text("AURUM  /  價格圖鑑",-.137f,.084f,.011f);prices.Icon(row.id);
        prices.Text(row.id+"   /   30",-.136f,-.050f,.009f);
        prices.Text(row.title,.009f,.080f,.017f);prices.Text(row.form+"  "+row.stone,.01f,.052f,.011f);
        prices.Text("典藏基準價",.01f,.026f,.010f);prices.Text(row.price.ToString("N0")+" 點",.01f,.008f,.015f);
        prices.Text("完整真品參考值",.01f,-.022f,.010f);
        prices.Text("＜ 上一頁",-.136f,-.069f,.012f);prices.Text("下一頁 ＞",.041f,-.069f,.012f);
    }
    void DrawReport(){
        record.Clear();record.Text("AURUM  /  鑑價紀錄",-.138f,.084f,.011f);
        record.Text("案件 "+caseNo.ToString("D3")+"   "+item.id,-.138f,.063f,.010f);
        record.Text(item.title,-.138f,.043f,.015f);record.Text(item.stone+"  "+item.form,-.138f,.019f,.010f);
        record.Text("基準 "+item.price.ToString("N0")+" 點",-.138f,-.002f,.011f);
        record.Text(lit?"光印  "+(fake?"雙點":"單點"):"光印  待照射",-.138f,-.022f,.010f);
        record.Text(seen?"鏡檢  "+flaws[flaw]:"鏡檢  待放大",-.138f,-.040f,.010f);
        record.Text(submitted?"結案估值":"檢驗指南",.009f,.082f,.015f);
        if(submitted){
            record.Text(verdict==fake?"判定正確":"判定有誤",.009f,.057f,.011f);
            record.Text(fake?"鑑定結果  贗品":"鑑定結果  真品",.009f,.037f,.010f);
            record.Text("真偽係數 "+(fake?"0.12":"1.00"),.009f,.018f,.010f);
            record.Text("品相係數 "+factors[flaw].ToString("0.00"),.009f,-.001f,.010f);
            record.Text("估值 "+Amount.ToString("N0")+" 點",.009f,-.023f,.013f);
            record.Text("下一位委託人 ＞",.009f,-.066f,.011f);
        }else{
            record.Text("燈照物件觀察光印",.009f,.056f,.010f);record.Text("單點真品  雙點贗品",.009f,.036f,.010f);
            record.Text("透過鏡圈觀察品相",.009f,.013f,.010f);
            record.Text(!arrived?"等待委託人":lit&&seen?"請提交判定":"完成兩項檢驗再判定",.009f,-.012f,.010f);
            record.Text("判為真品",-.134f,-.069f,.012f);record.Text("判為贗品",.041f,-.069f,.012f);
        }
    }
    // Desktop equivalent for reviewing a round without a headset.
    void OnGUI(){
        if(calibrated||!arrived||leaving)return;
        GUILayout.BeginArea(new Rect(12,12,230,360),GUI.skin.box);
        GUILayout.Label("AURUM   /   DESKTOP");
        if(GUILayout.Button("Torch inspection")){var p=mount.transform.position;torch.transform.position=p+new Vector3(.05f,.08f,-.09f);torch.transform.LookAt(p);}
        if(GUILayout.Button("Look through loupe")){var p=mount.transform.position;var dir=(eye.transform.position-p).normalized;loupe.transform.up=dir;loupe.transform.position=p+dir*.065f-loupe.transform.TransformVector(new Vector3(0,0,.023f));}
        GUILayout.Label((lit?(fake?"Mark: double":"Mark: single"):"Mark: ?")+"   /   "+(seen?new[]{"Clean","Bubbles","Fracture","Inclusion"}[flaw]:"Condition: ?"));
        GUILayout.BeginHorizontal();if(GUILayout.Button("Genuine"))Submit(false);if(GUILayout.Button("Replica"))Submit(true);GUILayout.EndHorizontal();
        if(submitted){GUILayout.Label((verdict==fake?"Correct":"Incorrect")+"   "+Amount+" credits");if(GUILayout.Button("Next visitor")){Restore(torch);Restore(loupe);Next();}}
        GUILayout.BeginHorizontal();if(GUILayout.Button("< Catalogue"))Flip(-1);if(GUILayout.Button("Catalogue >"))Flip(1);GUILayout.EndHorizontal();
        GUILayout.EndArea();
    }
    void OnDestroy(){if(Active==this)Active=null;}
}
}


