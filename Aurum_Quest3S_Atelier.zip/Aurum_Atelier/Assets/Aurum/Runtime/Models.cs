using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace Aurum {
[Serializable] public class Item { public string id,title,stone,form; public int price; }
[Serializable] public class Catalogue { public Item[] items; }
[Serializable] class Surface { public string name,hex; public float metal,rough; }
[Serializable] class Palette { public Surface[] colors; }
[Serializable] class Group { public string mat; public int[] tri; public float[] n; }
[Serializable] class Geometry { public float[] v; public Group[] groups; }

public static class Models {
    class Asset { public Mesh mesh; public Material[] materials; }
    static readonly Dictionary<string,Asset> cache = new Dictionary<string,Asset>();
    static readonly Dictionary<string,Material> materials = new Dictionary<string,Material>();
    public static T Data<T>(string key) {
        return JsonUtility.FromJson<T>(Resources.Load<TextAsset>("Aurum/"+key).text);
    }
    public static Material Paint(string name, Color c, bool flat=false) {
        Shader s=GraphicsSettings.currentRenderPipeline ?
            Shader.Find(flat?"Universal Render Pipeline/Unlit":"Universal Render Pipeline/Lit") :
            Shader.Find(flat?"Unlit/Texture":"Standard");
        if(flat) s=Resources.Load<Shader>("Aurum/Printed");
        if(!s) s=Shader.Find("Sprites/Default");
        var mat=new Material(s){name=name,color=c}; return mat;
    }
    static Asset Load(string key) {
        if(cache.TryGetValue(key,out var result)) return result;
        if(materials.Count==0) foreach(var p in Data<Palette>("Geometry/Palette").colors) {
            ColorUtility.TryParseHtmlString("#"+p.hex,out var c);
            var m=Paint(p.name,c);m.SetFloat("_Metallic",p.metal);
            m.SetFloat("_Glossiness",1-p.rough);m.SetFloat("_Smoothness",1-p.rough);materials.Add(p.name,m);
        }
        var g=Data<Geometry>("Geometry/"+key);
        var vertices=new List<Vector3>(); var normals=new List<Vector3>(); var sub=new List<int[]>(); var mats=new List<Material>();
        foreach(var group in g.groups) {
            var tri=new int[group.tri.Length];
            for(int i=0;i<tri.Length;i++) {
                if(group.n!=null)normals.Add(new Vector3(group.n[3*i],group.n[3*i+1],group.n[3*i+2]));
                int n=group.tri[i]*3;tri[i]=vertices.Count;
                vertices.Add(new Vector3(g.v[n],g.v[n+1],g.v[n+2]));
            }
            sub.Add(tri);mats.Add(materials[group.mat]);
        }
        var mesh=new Mesh{name=key,indexFormat=vertices.Count>65535?IndexFormat.UInt32:IndexFormat.UInt16};
        mesh.SetVertices(vertices);mesh.subMeshCount=sub.Count;
        for(int i=0;i<sub.Count;i++)mesh.SetTriangles(sub[i],i,false);
        if(normals.Count==vertices.Count)mesh.SetNormals(normals);else mesh.RecalculateNormals();mesh.RecalculateBounds();
        result=new Asset{mesh=mesh,materials=mats.ToArray()};cache.Add(key,result);return result;
    }
    public static GameObject Make(string key,Vector3 pos,Transform parent=null) {
        var a=Load(key);var go=new GameObject(key);go.transform.SetParent(parent,false);go.transform.localPosition=pos;
        go.AddComponent<MeshFilter>().sharedMesh=a.mesh;go.AddComponent<MeshRenderer>().sharedMaterials=a.materials;return go;
    }
}
}


