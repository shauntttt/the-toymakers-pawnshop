using UnityEditor;
namespace Aurum {
public class PrintTextureSettings:AssetPostprocessor {
    void OnPreprocessTexture(){
        if(!assetPath.StartsWith("Assets/Aurum/Resources/Aurum/"))return;
        var t=(TextureImporter)assetImporter;
        t.npotScale=TextureImporterNPOTScale.None;t.maxTextureSize=2048;
        t.wrapMode=UnityEngine.TextureWrapMode.Clamp;
        t.textureCompression=TextureImporterCompression.Uncompressed;
    }
}
}
