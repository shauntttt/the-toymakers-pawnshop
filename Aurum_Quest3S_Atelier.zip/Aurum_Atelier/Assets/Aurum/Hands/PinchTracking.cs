using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Hands;

namespace Aurum {
public static class PinchTracking {
    static readonly List<XRHandSubsystem> subsystems=new List<XRHandSubsystem>();
    static XRHandSubsystem active;
    static float nextScan;
    static readonly float[] gaps=new float[2];
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Register(){active=null;nextScan=0;Atelier.Finger=Read;Atelier.Gap=i=>gaps[i];}
    static Pose? Read(int i){
        if(active==null||!active.running){
            if(Time.unscaledTime<nextScan)return null;
            nextScan=Time.unscaledTime+1;SubsystemManager.GetSubsystems(subsystems);
            active=subsystems.Find(s=>s.running);if(active==null)return null;
        }
        var hand=i==0?active.leftHand:active.rightHand;
        if(!hand.isTracked||!hand.GetJoint(XRHandJointID.IndexTip).TryGetPose(out var index)||
           !hand.GetJoint(XRHandJointID.ThumbTip).TryGetPose(out var thumb)||
           !hand.GetJoint(XRHandJointID.Palm).TryGetPose(out var palm))return null;
        gaps[i]=Vector3.Distance(index.position,thumb.position);
        return new Pose((index.position+thumb.position)*.5f,palm.rotation);
    }
}
}
