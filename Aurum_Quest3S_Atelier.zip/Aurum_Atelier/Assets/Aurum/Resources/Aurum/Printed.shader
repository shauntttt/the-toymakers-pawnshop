Shader "Aurum/Printed Page" {
 Properties { _MainTex("Page",2D)="white"{} _Color("Tint",Color)=(1,1,1,1) }
 SubShader {
 Tags { "Queue"="AlphaTest" "RenderType"="TransparentCutout" }
 Pass {
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "UnityCG.cginc"
 struct Input {float4 vertex:POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct Output {float4 pos:SV_POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_OUTPUT_STEREO};
 sampler2D _MainTex;
 Output vert(Input v){Output o;UNITY_SETUP_INSTANCE_ID(v);UNITY_INITIALIZE_OUTPUT(Output,o);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.pos=UnityObjectToClipPos(v.vertex);o.uv=v.uv;return o;}
 fixed4 frag(Output i):SV_Target{fixed4 c=tex2D(_MainTex,i.uv);clip(c.a-.30);return c;}
 ENDCG
 }
 }
}
