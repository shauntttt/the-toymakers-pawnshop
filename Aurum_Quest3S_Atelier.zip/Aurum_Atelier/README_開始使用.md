# AURUM 珠寶鑑價室

## 打開作品

解壓縮到電腦後，開啟 `Blender/Aurum_Atelier.blend` 即可查看完整鑑價室。相機畫面是斜後方全景，切換材質預覽或算圖即可看到書頁。場景使用公尺。座椅、櫃體和工作桌合併為 Salon 網格，工具、角色、書和寶物各自獨立。

要試玩，從 Unity Hub 的 Add 選擇含有 Assets、Packages、ProjectSettings 的資料夾，使用 Unity 6 開啟（製作時使用 6000.6.3f1）。首次匯入請讓 Package Manager 取得套件。開啟 `Assets/Aurum/Salon.unity` 並按 Play。此場景在 Play 時建立模型與桌面互動，編輯模式下會看到場景根物件。

## 坐在櫃檯後鑑價

1. 等委託人走到桌前並放下物件。每次會從 30 件寶物中抽一件，一輪抽完才重新洗牌。
2. 用拇指與食指靠近工具後捏合抓取。鬆開時工具回到桌邊，寶物回到托盤。支援雙手分別握持工具和寶物。手指的小圓點是抓取位置。使用相容控制器時，以握把鍵抓取。
3. 將手電筒的金色燈頭指向寶物。照進光束的檢驗區會顯出單點或雙點光印。這是本遊戲自訂的出廠記號，單點代表真品，雙點代表贗品。
4. 讓鏡圈位在眼睛與物件中間，從圈內對準寶物，靠近至約 11 公分內。檢驗區會顯示放大的模型。可以轉動寶物觀察表面。氣泡、裂紋與內含物影響品相，真偽獨立抽選。
5. 左手邊的價本可拿近閱讀。捏一下頁底左右兩端可翻頁。每一筆有物件編號、名稱、材質、形制、模型圖示與完整真品基準價。
6. 在鑑價書讀取本案的光印與鏡檢紀錄。兩項檢查皆完成後，捏一下頁底左側「判為真品」或右側「判為贗品」。結案頁顯示判定是否正確、實際真偽、真偽係數、品相係數和估值。按「下一位委託人」後，現有委託人帶走寶物，下一位入場。
7. 在桌面模式，左上角的 Torch inspection 和 Look through loupe 會將工具移到可檢查的位置。Genuine、Replica 提交判定，Next visitor 換客，Catalogue 翻價本。

## 計價規則

金額以遊戲點數表示。估值是基準價乘上真偽係數，再乘上品相係數，最後四捨五入至整點。真品係數為 1.00，贗品為 0.12。潔淨、氣泡、裂紋、內含物的品相係數依序為 1.00、0.83、0.62、0.88。

例如緋紅日冕的基準價為 18,500 點，本案若為真品且帶裂紋，估值為 18,500 × 1.00 × 0.62 = 11,470 點。Blender 中攤開的鑑價書以此案為示例。Unity 書頁則依當次案件更新。

## Meta Quest 3S

使用 Unity Hub 安裝相同 Editor 版本的 Android Build Support、SDK、NDK、OpenJDK。在 Build Profiles 將平台切到 Android，確認場景清單有 Salon。專案已指定 Android ARM64、IL2CPP 與新版 Input System。

在 Project Settings → XR Plug-in Management 的 Android 頁啟用 OpenXR 與 Initialize XR on Startup。在 Android 的 OpenXR 設定啟用 Meta Quest Support 和 Hand Tracking Subsystem；需要控制器時加入 Oculus Touch Controller Profile。執行 XR Project Validation，處理當前套件列出的必要設定，再 Build And Run 至已開啟開發者模式、已授權 USB 偵錯的裝置。頭盔中開啟手部追蹤，坐定並面向前方啟動，第一次讀到頭部姿態會校準至櫃檯後。

手部程式以 XR Hands 的掌心姿態、食指尖與拇指尖驅動抓取。此版本附可修改的 Unity 專案與模型，Quest 真機的追蹤穩定度、文字閱讀距離及幀率仍需上機驗收。

Unity 官方說明：[XR Hands 的 OpenXR 手部追蹤](https://docs.unity3d.com/Packages/com.unity.xr.hands@1.7/manual/openxr-features/handtracking.html)。

## 移入自己的遊戲

| 位置 | 內容 |
| --- | --- |
| Exchange | 42 個各自帶材質的 FBX，可將所需檔案拖到既有 Unity 專案的 Assets |
| Blender | 可編輯母場景、30 件寶物陳列、坐姿鑑價師、訪客、道具與示例書頁 |
| Assets/Aurum | 可整組移植的遊戲場景、執行程式、模型資料、書頁與圖示；手勢使用 XR Hands |
| Assets/Aurum/Resources/Aurum/Catalogue.json | 30 件寶物的名稱、形制、材質和可修改基準價 |
| Treasure_Register.png | 30 件寶物圖示與價目總覽 |
| Atelier_Preview.png | Blender 場景算圖 |

J01–J30 對應圖鑑編號。Bubble、Crack、Inclusion 是各自獨立的物件；Unity 會往寶物外表面投射射線挑選附著位置，再沿表面法向對齊瑕疵。可從 Blender 或 FBX 修改造型。Exchange 是通用交換檔；隨附遊戲使用 Resources/Aurum/Geometry 的網格資料載入，單獨改 FBX 時需在自己的場景替換模型。訪客採整體位移進出，角色為靜態網格。放大鏡以立體放大模型呈現觀察結果。
